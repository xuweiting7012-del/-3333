import React from 'react';
import { TreeState } from '../types';

interface OverlayProps {
  treeState: TreeState;
  onToggle: () => void;
}

const Overlay: React.FC<OverlayProps> = ({ treeState, onToggle }) => {
  const getButtonText = () => {
    switch (treeState) {
      case TreeState.TREE_SHAPE: return 'Reveal Message';
      case TreeState.TEXT_SHAPE: return 'Reform Tree';
      default: return 'Reveal Message';
    }
  };

  const getStatusText = () => {
    switch (treeState) {
      case TreeState.TREE_SHAPE: return 'Crystalline Tree';
      case TreeState.TEXT_SHAPE: return 'Winter Whispers';
      default: return 'Stardust Field';
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8 md:p-12 z-10">
      {/* Header */}
      <div className="flex flex-col items-start space-y-2">
        <h1 className="text-3xl md:text-5xl font-light text-white tracking-[0.2em] uppercase drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
          Arix Signature
        </h1>
        <p className="text-blue-100/70 text-sm md:text-base tracking-widest font-light border-l-2 border-cyan-400 pl-4">
          INTERACTIVE CHRISTMAS EXPERIENCE
        </p>
      </div>

      {/* Control Area */}
      <div className="flex flex-col items-center justify-end w-full pb-8">
        <button
          onClick={onToggle}
          className={`
            pointer-events-auto
            group relative px-10 py-4 
            backdrop-blur-md bg-white/5 border border-white/20 
            hover:bg-white/10 hover:border-cyan-300/50 
            transition-all duration-500 ease-out
            rounded-full overflow-hidden
          `}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/0 via-cyan-500/10 to-cyan-500/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
          
          <span className="relative flex items-center space-x-3">
            <span className={`
              w-2 h-2 rounded-full shadow-[0_0_8px_currentColor] transition-colors duration-500
              ${treeState === TreeState.TREE_SHAPE ? 'bg-cyan-300 text-cyan-300' : 'bg-rose-300 text-rose-300'}
            `} />
            <span className="text-white font-light tracking-[0.15em] text-sm uppercase">
              {getButtonText()}
            </span>
          </span>
        </button>
        
        <p className="mt-4 text-white/30 text-xs tracking-widest uppercase">
          Status: <span className="text-white/60">{getStatusText()}</span>
        </p>
      </div>
    </div>
  );
};

export default Overlay;